package com.mubaobama.ai;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.speech.*;
import android.speech.tts.TextToSpeech;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.*;
import java.net.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, header, body, bottom, messages;
    EditText prompt;
    String currentPage="Chat", model="Demo mode";
    boolean dark=false;
    TextToSpeech tts;
    final ArrayList<String> history=new ArrayList<>();
    final int PICK_FILE=31;
    int bg, fg, card, accent;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getPreferences(0);
        dark=getPreferences(0).getBoolean("dark",false);
        tts=new TextToSpeech(this, status -> {});
        loadHistory();
        showPage("Chat");
    }
    int c(String s){return Color.parseColor(s);}
    void palette(){
        bg=c(dark?"#171714":"#F7F5F0"); fg=c(dark?"#F3F0E8":"#292720");
        card=c(dark?"#262521":"#FFFFFF"); accent=c("#B66A3C");
    }
    TextView text(String s,int size,boolean bold){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(fg);
        if(bold)t.setTypeface(null,1); t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    GradientDrawable shape(int color,int radius){
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }
    Button button(String label,Runnable action){
        Button b=new Button(this); b.setText(label); b.setAllCaps(false); b.setTextColor(fg);
        b.setBackground(shape(card,24)); b.setOnClickListener(v->action.run()); return b;
    }
    void showPage(String page){
        currentPage=page; palette();
        root=new LinearLayout(this); root.setOrientation(1); root.setBackgroundColor(bg);
        setContentView(root);
        header=new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL); header.setPadding(16,10,12,10);
        TextView brand=text("✦  Muba-Obama",20,true); header.addView(brand,new LinearLayout.LayoutParams(0,56,1));
        header.addView(button(dark?"☀":"☾",()->{dark=!dark;getPreferences(0).edit().putBoolean("dark",dark).apply();showPage(currentPage);}));
        root.addView(header);
        ScrollView scroll=new ScrollView(this); body=new LinearLayout(this); body.setOrientation(1); body.setPadding(16,8,16,16);
        scroll.addView(body); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        switch(page){
            case "Chat": buildChat(); break;
            case "History": buildHistory(); break;
            case "AI Models": buildModels(); break;
            case "Tools": buildTools(); break;
            case "Developer": buildDeveloper(); break;
            case "Settings": buildSettings(); break;
            case "Phone Controls": buildPhone(); break;
        }
        LinearLayout nav=new LinearLayout(this); nav.setPadding(4,4,4,8); nav.setBackgroundColor(card);
        String[] pages={"Chat","History","AI Models","Tools","Developer","Settings"};
        for(String p:pages){ Button b=button(p,()->showPage(p)); b.setTextSize(10); nav.addView(b,new LinearLayout.LayoutParams(0,54,1)); }
        root.addView(nav);
    }
    void buildChat(){
        TextView title=text("What can I help you with?",25,true); body.addView(title);
        TextView sub=text("Ask a question, explore an idea, or work on a task.",15,false); sub.setPadding(0,8,0,18); body.addView(sub);
        String[] suggestions={"Explain a difficult topic","Help me write code","Summarize a document","Brainstorm ideas"};
        for(String s:suggestions) body.addView(button("✧  "+s,()->{prompt.setText(s);sendMessage();}));
        messages=new LinearLayout(this); messages.setOrientation(1); messages.setPadding(0,18,0,10); body.addView(messages);
        for(String h:history) addMessageView(h);
        LinearLayout tools=new LinearLayout(this);
        tools.addView(button("＋ File",()->pickFile()),new LinearLayout.LayoutParams(0,52,1));
        tools.addView(button("🎙 Voice",()->startVoice()),new LinearLayout.LayoutParams(0,52,1));
        body.addView(tools);
        prompt=new EditText(this); prompt.setTextColor(fg); prompt.setHintTextColor(c("#88847C"));
        prompt.setHint("Message Muba-Obama..."); prompt.setMinLines(2); prompt.setMaxLines(5); prompt.setPadding(14,12,14,12);
        prompt.setBackground(shape(card,22)); body.addView(prompt);
        body.addView(button("Send ↑",()->sendMessage()));
        body.addView(button("Search the web",()->webSearch()));
    }
    void addMessageView(String s){
        TextView t=text(s,15,false); t.setPadding(14,12,14,12); t.setBackground(shape(card,18));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,5,0,5); messages.addView(t,lp);
    }
    void sendMessage(){
        if(prompt==null)return; String q=prompt.getText().toString().trim(); if(q.isEmpty())return;
        String user="You: "+q; history.add(user); addMessageView(user); prompt.setText("");
        history.add("Muba-Obama: "+localReply(q)); addMessageView(history.get(history.size()-1)); saveHistory();
        ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(prompt.getWindowToken(),0);
    }
    String localReply(String q){
        return "I'm running in demo mode. To receive AI-generated answers, connect a provider through a secure backend. You asked: "+q;
    }
    void buildHistory(){
        body.addView(text("Conversation history",25,true));
        body.addView(button("Clear history",()->new AlertDialog.Builder(this).setMessage("Delete all saved chats?").setPositiveButton("Delete",(d,w)->{history.clear();saveHistory();showPage("History");}).setNegativeButton("Cancel",null).show()));
        for(String h:history){ TextView t=text(h,15,false); t.setPadding(12,12,12,12); body.addView(t); }
        if(history.isEmpty())body.addView(text("Your conversations will appear here.",15,false));
    }
    void buildModels(){
        body.addView(text("Choose an AI model",25,true));
        body.addView(text("Provider selection is prepared for integration. Demo mode works without an API key.",14,false));
        String[] models={"Demo mode","OpenAI","Anthropic Claude","Google Gemini","OpenRouter (multiple models)","Local / self-hosted"};
        for(String m:models)body.addView(button((model.equals(m)?"✓  ":"") +m,()->{model=m;getPreferences(0).edit().putString("model",model).apply();showPage("AI Models");}));
        body.addView(text("Selected: "+model,16,true));
    }
    void buildTools(){
        body.addView(text("AI Tools",25,true));
        body.addView(button("Upload image or document",()->pickFile()));
        body.addView(button("Web search",()->webSearch()));
        body.addView(button("Voice conversation",()->startVoice()));
        body.addView(button("Code assistant",()->{showPage("Chat"); if(prompt!=null)prompt.setText("Help me write and explain code: ");}));
        body.addView(text("Document and image analysis require an AI provider integration. Files are selected locally and are not uploaded in demo mode.",14,false));
    }
    void buildDeveloper(){
        body.addView(text("About the Developer",25,true));
        TextView name=text("Muba-Obama",23,true); name.setPadding(0,18,0,8); body.addView(name);
        body.addView(text("Independent developer and creator of Muba-Obama AI.",16,false));
        body.addView(text("Mission",18,true)); body.addView(text("Build a helpful, accessible, and professional AI assistant for everyday learning, creativity, and productivity.",15,false));
        body.addView(text("Contact",18,true));
        body.addView(button("Email developer",()->{
            Intent i=new Intent(Intent.ACTION_SENDTO,Uri.parse("mailto:")); i.putExtra(Intent.EXTRA_SUBJECT,"Muba-Obama AI support");
            try{startActivity(i);}catch(Exception e){toast("No email app found");}
        }));
        body.addView(text("Add your public email address, website, and social links before publishing.",13,false));
    }
    void buildSettings(){
        body.addView(text("Settings",25,true));
        body.addView(button("Toggle light / dark theme",()->{dark=!dark;getPreferences(0).edit().putBoolean("dark",dark).apply();showPage("Settings");}));
        body.addView(button("Manage phone controls",()->showPage("Phone Controls")));
        body.addView(button("Privacy & safety",()->new AlertDialog.Builder(this).setTitle("Privacy").setMessage("Demo mode stores chat history locally on this device. No AI provider is connected.").setPositiveButton("OK",null).show()));
        body.addView(text("Version 1.0 • Muba-Obama AI",14,false));
    }
    void buildPhone(){
        body.addView(text("Phone Controls",25,true));
        body.addView(text("Accessibility controls are optional and require you to enable the service in Android Settings. This starter does not silently control other apps.",15,false));
        body.addView(button("Open Accessibility Settings",()->{try{startActivity(new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS));}catch(Exception e){toast("Unable to open settings");}}));
        body.addView(text("Use accessibility permissions only for clear, user-requested functions. This starter service does not read screen content or perform gestures.",13,false));
    }
    void pickFile(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("*/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
        try{startActivityForResult(i,PICK_FILE);}catch(Exception e){toast("File picker unavailable");}
    }
    @Override protected void onActivityResult(int req,int res,Intent data){
        super.onActivityResult(req,res,data);
        if(req==PICK_FILE && res==RESULT_OK && data!=null && data.getData()!=null){
            Uri uri=data.getData(); String label=uri.getLastPathSegment();
            new AlertDialog.Builder(this).setTitle("File selected").setMessage("Selected: "+label+"\n\nConnect an AI provider to analyze this file.").setPositiveButton("OK",null).show();
        }
    }
    void startVoice(){
        if(!SpeechRecognizer.isRecognitionAvailable(this)){toast("Speech recognition is unavailable");return;}
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_PROMPT,"Speak to Muba-Obama");
        try{startActivityForResult(i,44);}catch(Exception e){toast("Voice input could not start");}
    }
    void webSearch(){
        String q=prompt==null?"":prompt.getText().toString().trim();
        if(q.isEmpty())q=""; 
        try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/search?q="+Uri.encode(q))));}
        catch(Exception e){toast("No browser available");}
    }
    void loadHistory(){
        model=getPreferences(0).getString("model","Demo mode");
        try{JSONArray a=new JSONArray(getPreferences(0).getString("history","[]")); for(int i=0;i<a.length();i++)history.add(a.getString(i));}catch(Exception ignored){}
    }
    void saveHistory(){
        JSONArray a=new JSONArray(); for(String s:history)a.put(s);
        getPreferences(0).edit().putString("history",a.toString()).apply();
    }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @Override protected void onDestroy(){if(tts!=null)tts.shutdown();super.onDestroy();}
}
