package com.mubaobama.ai;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;

/** Minimal, privacy-conscious service scaffold. No screen content is collected or actions performed. */
public class PhoneControlService extends AccessibilityService {
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        // Intentionally no-op. Add only transparent, user-requested accessibility functionality.
    }
    @Override public void onInterrupt() { }
}
