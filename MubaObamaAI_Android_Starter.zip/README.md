# Muba-Obama AI — Android Java starter

A Java/Android Studio starter project with:
- Claude-inspired warm interface and light/dark theme toggle
- Chat UI and local conversation history
- Model selection UI (demo, OpenAI, Claude, Gemini, OpenRouter, local)
- Voice input entry point
- File picker for documents/images
- Browser-based web search
- Developer/about page and email intent
- Accessibility settings shortcut and minimal no-op service

## Important limitations
This is a **starter scaffold**, not a fully connected AI product. Chat replies are demo text until a secure backend is connected. Model choices are UI-only. Image/document analysis, real web-grounded AI answers, and actual multi-provider routing are not implemented. The app does not include API keys.

## Open in Android Studio
1. Unzip the project.
2. Open the `MubaObamaAI` folder in Android Studio.
3. Allow Gradle sync and install Android SDK 35 (or adjust compileSdk to your installed SDK).
4. Run on an Android device or emulator.

## Before release
- Implement a backend API that stores provider keys server-side.
- Add authentication, rate limits, request validation, and privacy policy.
- Implement real provider adapters and streaming chat.
- Implement file parsing and image upload with explicit consent.
- Add tests, app icon, and production branding.
- Review Android accessibility policy and declare only needed capabilities.
- Replace generic developer/contact copy with verified details.

## Build note
This project uses Android Gradle Plugin 8.7.3 and Java source. Gradle wrapper files are not included; Android Studio can generate them.
